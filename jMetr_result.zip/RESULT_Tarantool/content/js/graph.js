/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 714.0, "minX": 0.0, "maxY": 10002.0, "series": [{"data": [[0.0, 714.0], [0.1, 714.0], [0.2, 714.0], [0.3, 714.0], [0.4, 714.0], [0.5, 714.0], [0.6, 714.0], [0.7, 714.0], [0.8, 714.0], [0.9, 714.0], [1.0, 943.0], [1.1, 943.0], [1.2, 943.0], [1.3, 943.0], [1.4, 943.0], [1.5, 943.0], [1.6, 943.0], [1.7, 943.0], [1.8, 943.0], [1.9, 943.0], [2.0, 1088.0], [2.1, 1088.0], [2.2, 1088.0], [2.3, 1088.0], [2.4, 1088.0], [2.5, 1088.0], [2.6, 1088.0], [2.7, 1088.0], [2.8, 1088.0], [2.9, 1088.0], [3.0, 1184.0], [3.1, 1184.0], [3.2, 1184.0], [3.3, 1184.0], [3.4, 1184.0], [3.5, 1184.0], [3.6, 1184.0], [3.7, 1184.0], [3.8, 1184.0], [3.9, 1184.0], [4.0, 1186.0], [4.1, 1186.0], [4.2, 1186.0], [4.3, 1186.0], [4.4, 1186.0], [4.5, 1186.0], [4.6, 1186.0], [4.7, 1186.0], [4.8, 1186.0], [4.9, 1186.0], [5.0, 1264.0], [5.1, 1264.0], [5.2, 1264.0], [5.3, 1264.0], [5.4, 1264.0], [5.5, 1264.0], [5.6, 1264.0], [5.7, 1264.0], [5.8, 1264.0], [5.9, 1264.0], [6.0, 1269.0], [6.1, 1269.0], [6.2, 1269.0], [6.3, 1269.0], [6.4, 1269.0], [6.5, 1269.0], [6.6, 1269.0], [6.7, 1269.0], [6.8, 1269.0], [6.9, 1269.0], [7.0, 1339.0], [7.1, 1339.0], [7.2, 1339.0], [7.3, 1339.0], [7.4, 1339.0], [7.5, 1339.0], [7.6, 1339.0], [7.7, 1339.0], [7.8, 1339.0], [7.9, 1339.0], [8.0, 1445.0], [8.1, 1445.0], [8.2, 1445.0], [8.3, 1445.0], [8.4, 1445.0], [8.5, 1445.0], [8.6, 1445.0], [8.7, 1445.0], [8.8, 1445.0], [8.9, 1445.0], [9.0, 1530.0], [9.1, 1530.0], [9.2, 1530.0], [9.3, 1530.0], [9.4, 1530.0], [9.5, 1530.0], [9.6, 1530.0], [9.7, 1530.0], [9.8, 1530.0], [9.9, 1530.0], [10.0, 1812.0], [10.1, 1812.0], [10.2, 1812.0], [10.3, 1812.0], [10.4, 1812.0], [10.5, 1812.0], [10.6, 1812.0], [10.7, 1812.0], [10.8, 1812.0], [10.9, 1812.0], [11.0, 1818.0], [11.1, 1818.0], [11.2, 1818.0], [11.3, 1818.0], [11.4, 1818.0], [11.5, 1818.0], [11.6, 1818.0], [11.7, 1818.0], [11.8, 1818.0], [11.9, 1818.0], [12.0, 1846.0], [12.1, 1846.0], [12.2, 1846.0], [12.3, 1846.0], [12.4, 1846.0], [12.5, 1846.0], [12.6, 1846.0], [12.7, 1846.0], [12.8, 1846.0], [12.9, 1846.0], [13.0, 1924.0], [13.1, 1924.0], [13.2, 1924.0], [13.3, 1924.0], [13.4, 1924.0], [13.5, 1924.0], [13.6, 1924.0], [13.7, 1924.0], [13.8, 1924.0], [13.9, 1924.0], [14.0, 2041.0], [14.1, 2041.0], [14.2, 2041.0], [14.3, 2041.0], [14.4, 2041.0], [14.5, 2041.0], [14.6, 2041.0], [14.7, 2041.0], [14.8, 2041.0], [14.9, 2041.0], [15.0, 2119.0], [15.1, 2119.0], [15.2, 2119.0], [15.3, 2119.0], [15.4, 2119.0], [15.5, 2119.0], [15.6, 2119.0], [15.7, 2119.0], [15.8, 2119.0], [15.9, 2119.0], [16.0, 2150.0], [16.1, 2150.0], [16.2, 2150.0], [16.3, 2150.0], [16.4, 2150.0], [16.5, 2150.0], [16.6, 2150.0], [16.7, 2150.0], [16.8, 2150.0], [16.9, 2150.0], [17.0, 2193.0], [17.1, 2193.0], [17.2, 2193.0], [17.3, 2193.0], [17.4, 2193.0], [17.5, 2193.0], [17.6, 2193.0], [17.7, 2193.0], [17.8, 2193.0], [17.9, 2193.0], [18.0, 2215.0], [18.1, 2215.0], [18.2, 2215.0], [18.3, 2215.0], [18.4, 2215.0], [18.5, 2215.0], [18.6, 2215.0], [18.7, 2215.0], [18.8, 2215.0], [18.9, 2215.0], [19.0, 2242.0], [19.1, 2242.0], [19.2, 2242.0], [19.3, 2242.0], [19.4, 2242.0], [19.5, 2242.0], [19.6, 2242.0], [19.7, 2242.0], [19.8, 2242.0], [19.9, 2242.0], [20.0, 2381.0], [20.1, 2381.0], [20.2, 2381.0], [20.3, 2381.0], [20.4, 2381.0], [20.5, 2381.0], [20.6, 2381.0], [20.7, 2381.0], [20.8, 2381.0], [20.9, 2381.0], [21.0, 2383.0], [21.1, 2383.0], [21.2, 2383.0], [21.3, 2383.0], [21.4, 2383.0], [21.5, 2383.0], [21.6, 2383.0], [21.7, 2383.0], [21.8, 2383.0], [21.9, 2383.0], [22.0, 2428.0], [22.1, 2428.0], [22.2, 2428.0], [22.3, 2428.0], [22.4, 2428.0], [22.5, 2428.0], [22.6, 2428.0], [22.7, 2428.0], [22.8, 2428.0], [22.9, 2428.0], [23.0, 2577.0], [23.1, 2577.0], [23.2, 2577.0], [23.3, 2577.0], [23.4, 2577.0], [23.5, 2577.0], [23.6, 2577.0], [23.7, 2577.0], [23.8, 2577.0], [23.9, 2577.0], [24.0, 2601.0], [24.1, 2601.0], [24.2, 2601.0], [24.3, 2601.0], [24.4, 2601.0], [24.5, 2601.0], [24.6, 2601.0], [24.7, 2601.0], [24.8, 2601.0], [24.9, 2601.0], [25.0, 2605.0], [25.1, 2605.0], [25.2, 2605.0], [25.3, 2605.0], [25.4, 2605.0], [25.5, 2605.0], [25.6, 2605.0], [25.7, 2605.0], [25.8, 2605.0], [25.9, 2605.0], [26.0, 2637.0], [26.1, 2637.0], [26.2, 2637.0], [26.3, 2637.0], [26.4, 2637.0], [26.5, 2637.0], [26.6, 2637.0], [26.7, 2637.0], [26.8, 2637.0], [26.9, 2637.0], [27.0, 2645.0], [27.1, 2645.0], [27.2, 2645.0], [27.3, 2645.0], [27.4, 2645.0], [27.5, 2645.0], [27.6, 2645.0], [27.7, 2645.0], [27.8, 2645.0], [27.9, 2645.0], [28.0, 2669.0], [28.1, 2669.0], [28.2, 2669.0], [28.3, 2669.0], [28.4, 2669.0], [28.5, 2669.0], [28.6, 2669.0], [28.7, 2669.0], [28.8, 2669.0], [28.9, 2669.0], [29.0, 2714.0], [29.1, 2714.0], [29.2, 2714.0], [29.3, 2714.0], [29.4, 2714.0], [29.5, 2714.0], [29.6, 2714.0], [29.7, 2714.0], [29.8, 2714.0], [29.9, 2714.0], [30.0, 2775.0], [30.1, 2775.0], [30.2, 2775.0], [30.3, 2775.0], [30.4, 2775.0], [30.5, 2775.0], [30.6, 2775.0], [30.7, 2775.0], [30.8, 2775.0], [30.9, 2775.0], [31.0, 2841.0], [31.1, 2841.0], [31.2, 2841.0], [31.3, 2841.0], [31.4, 2841.0], [31.5, 2841.0], [31.6, 2841.0], [31.7, 2841.0], [31.8, 2841.0], [31.9, 2841.0], [32.0, 2852.0], [32.1, 2852.0], [32.2, 2852.0], [32.3, 2852.0], [32.4, 2852.0], [32.5, 2852.0], [32.6, 2852.0], [32.7, 2852.0], [32.8, 2852.0], [32.9, 2852.0], [33.0, 2884.0], [33.1, 2884.0], [33.2, 2884.0], [33.3, 2884.0], [33.4, 2884.0], [33.5, 2884.0], [33.6, 2884.0], [33.7, 2884.0], [33.8, 2884.0], [33.9, 2884.0], [34.0, 2943.0], [34.1, 2943.0], [34.2, 2943.0], [34.3, 2943.0], [34.4, 2943.0], [34.5, 2943.0], [34.6, 2943.0], [34.7, 2943.0], [34.8, 2943.0], [34.9, 2943.0], [35.0, 2994.0], [35.1, 2994.0], [35.2, 2994.0], [35.3, 2994.0], [35.4, 2994.0], [35.5, 2994.0], [35.6, 2994.0], [35.7, 2994.0], [35.8, 2994.0], [35.9, 2994.0], [36.0, 2995.0], [36.1, 2995.0], [36.2, 2995.0], [36.3, 2995.0], [36.4, 2995.0], [36.5, 2995.0], [36.6, 2995.0], [36.7, 2995.0], [36.8, 2995.0], [36.9, 2995.0], [37.0, 3243.0], [37.1, 3243.0], [37.2, 3243.0], [37.3, 3243.0], [37.4, 3243.0], [37.5, 3243.0], [37.6, 3243.0], [37.7, 3243.0], [37.8, 3243.0], [37.9, 3243.0], [38.0, 3256.0], [38.1, 3256.0], [38.2, 3256.0], [38.3, 3256.0], [38.4, 3256.0], [38.5, 3256.0], [38.6, 3256.0], [38.7, 3256.0], [38.8, 3256.0], [38.9, 3256.0], [39.0, 3275.0], [39.1, 3275.0], [39.2, 3275.0], [39.3, 3275.0], [39.4, 3275.0], [39.5, 3275.0], [39.6, 3275.0], [39.7, 3275.0], [39.8, 3275.0], [39.9, 3275.0], [40.0, 3289.0], [40.1, 3289.0], [40.2, 3289.0], [40.3, 3289.0], [40.4, 3289.0], [40.5, 3289.0], [40.6, 3289.0], [40.7, 3289.0], [40.8, 3289.0], [40.9, 3289.0], [41.0, 3342.0], [41.1, 3342.0], [41.2, 3342.0], [41.3, 3342.0], [41.4, 3342.0], [41.5, 3342.0], [41.6, 3342.0], [41.7, 3342.0], [41.8, 3342.0], [41.9, 3342.0], [42.0, 3452.0], [42.1, 3452.0], [42.2, 3452.0], [42.3, 3452.0], [42.4, 3452.0], [42.5, 3452.0], [42.6, 3452.0], [42.7, 3452.0], [42.8, 3452.0], [42.9, 3452.0], [43.0, 3801.0], [43.1, 3801.0], [43.2, 3801.0], [43.3, 3801.0], [43.4, 3801.0], [43.5, 3801.0], [43.6, 3801.0], [43.7, 3801.0], [43.8, 3801.0], [43.9, 3801.0], [44.0, 3822.0], [44.1, 3822.0], [44.2, 3822.0], [44.3, 3822.0], [44.4, 3822.0], [44.5, 3822.0], [44.6, 3822.0], [44.7, 3822.0], [44.8, 3822.0], [44.9, 3822.0], [45.0, 4049.0], [45.1, 4049.0], [45.2, 4049.0], [45.3, 4049.0], [45.4, 4049.0], [45.5, 4049.0], [45.6, 4049.0], [45.7, 4049.0], [45.8, 4049.0], [45.9, 4049.0], [46.0, 4086.0], [46.1, 4086.0], [46.2, 4086.0], [46.3, 4086.0], [46.4, 4086.0], [46.5, 4086.0], [46.6, 4086.0], [46.7, 4086.0], [46.8, 4086.0], [46.9, 4086.0], [47.0, 4209.0], [47.1, 4209.0], [47.2, 4209.0], [47.3, 4209.0], [47.4, 4209.0], [47.5, 4209.0], [47.6, 4209.0], [47.7, 4209.0], [47.8, 4209.0], [47.9, 4209.0], [48.0, 4296.0], [48.1, 4296.0], [48.2, 4296.0], [48.3, 4296.0], [48.4, 4296.0], [48.5, 4296.0], [48.6, 4296.0], [48.7, 4296.0], [48.8, 4296.0], [48.9, 4296.0], [49.0, 4463.0], [49.1, 4463.0], [49.2, 4463.0], [49.3, 4463.0], [49.4, 4463.0], [49.5, 4463.0], [49.6, 4463.0], [49.7, 4463.0], [49.8, 4463.0], [49.9, 4463.0], [50.0, 4624.0], [50.1, 4624.0], [50.2, 4624.0], [50.3, 4624.0], [50.4, 4624.0], [50.5, 4624.0], [50.6, 4624.0], [50.7, 4624.0], [50.8, 4624.0], [50.9, 4624.0], [51.0, 4708.0], [51.1, 4708.0], [51.2, 4708.0], [51.3, 4708.0], [51.4, 4708.0], [51.5, 4708.0], [51.6, 4708.0], [51.7, 4708.0], [51.8, 4708.0], [51.9, 4708.0], [52.0, 4725.0], [52.1, 4725.0], [52.2, 4725.0], [52.3, 4725.0], [52.4, 4725.0], [52.5, 4725.0], [52.6, 4725.0], [52.7, 4725.0], [52.8, 4725.0], [52.9, 4725.0], [53.0, 4726.0], [53.1, 4726.0], [53.2, 4726.0], [53.3, 4726.0], [53.4, 4726.0], [53.5, 4726.0], [53.6, 4726.0], [53.7, 4726.0], [53.8, 4726.0], [53.9, 4726.0], [54.0, 4734.0], [54.1, 4734.0], [54.2, 4734.0], [54.3, 4734.0], [54.4, 4734.0], [54.5, 4734.0], [54.6, 4734.0], [54.7, 4734.0], [54.8, 4734.0], [54.9, 4734.0], [55.0, 4765.0], [55.1, 4765.0], [55.2, 4765.0], [55.3, 4765.0], [55.4, 4765.0], [55.5, 4765.0], [55.6, 4765.0], [55.7, 4765.0], [55.8, 4765.0], [55.9, 4765.0], [56.0, 4788.0], [56.1, 4788.0], [56.2, 4788.0], [56.3, 4788.0], [56.4, 4788.0], [56.5, 4788.0], [56.6, 4788.0], [56.7, 4788.0], [56.8, 4788.0], [56.9, 4788.0], [57.0, 4837.0], [57.1, 4837.0], [57.2, 4837.0], [57.3, 4837.0], [57.4, 4837.0], [57.5, 4837.0], [57.6, 4837.0], [57.7, 4837.0], [57.8, 4837.0], [57.9, 4837.0], [58.0, 4839.0], [58.1, 4839.0], [58.2, 4839.0], [58.3, 4839.0], [58.4, 4839.0], [58.5, 4839.0], [58.6, 4839.0], [58.7, 4839.0], [58.8, 4839.0], [58.9, 4839.0], [59.0, 4907.0], [59.1, 4907.0], [59.2, 4907.0], [59.3, 4907.0], [59.4, 4907.0], [59.5, 4907.0], [59.6, 4907.0], [59.7, 4907.0], [59.8, 4907.0], [59.9, 4907.0], [60.0, 4969.0], [60.1, 4969.0], [60.2, 4969.0], [60.3, 4969.0], [60.4, 4969.0], [60.5, 4969.0], [60.6, 4969.0], [60.7, 4969.0], [60.8, 4969.0], [60.9, 4969.0], [61.0, 5043.0], [61.1, 5043.0], [61.2, 5043.0], [61.3, 5043.0], [61.4, 5043.0], [61.5, 5043.0], [61.6, 5043.0], [61.7, 5043.0], [61.8, 5043.0], [61.9, 5043.0], [62.0, 5055.0], [62.1, 5055.0], [62.2, 5055.0], [62.3, 5055.0], [62.4, 5055.0], [62.5, 5055.0], [62.6, 5055.0], [62.7, 5055.0], [62.8, 5055.0], [62.9, 5055.0], [63.0, 5055.0], [63.1, 5055.0], [63.2, 5055.0], [63.3, 5055.0], [63.4, 5055.0], [63.5, 5055.0], [63.6, 5055.0], [63.7, 5055.0], [63.8, 5055.0], [63.9, 5055.0], [64.0, 5217.0], [64.1, 5217.0], [64.2, 5217.0], [64.3, 5217.0], [64.4, 5217.0], [64.5, 5217.0], [64.6, 5217.0], [64.7, 5217.0], [64.8, 5217.0], [64.9, 5217.0], [65.0, 5218.0], [65.1, 5218.0], [65.2, 5218.0], [65.3, 5218.0], [65.4, 5218.0], [65.5, 5218.0], [65.6, 5218.0], [65.7, 5218.0], [65.8, 5218.0], [65.9, 5218.0], [66.0, 5239.0], [66.1, 5239.0], [66.2, 5239.0], [66.3, 5239.0], [66.4, 5239.0], [66.5, 5239.0], [66.6, 5239.0], [66.7, 5239.0], [66.8, 5239.0], [66.9, 5239.0], [67.0, 5335.0], [67.1, 5335.0], [67.2, 5335.0], [67.3, 5335.0], [67.4, 5335.0], [67.5, 5335.0], [67.6, 5335.0], [67.7, 5335.0], [67.8, 5335.0], [67.9, 5335.0], [68.0, 5350.0], [68.1, 5350.0], [68.2, 5350.0], [68.3, 5350.0], [68.4, 5350.0], [68.5, 5350.0], [68.6, 5350.0], [68.7, 5350.0], [68.8, 5350.0], [68.9, 5350.0], [69.0, 7238.0], [69.1, 7238.0], [69.2, 7238.0], [69.3, 7238.0], [69.4, 7238.0], [69.5, 7238.0], [69.6, 7238.0], [69.7, 7238.0], [69.8, 7238.0], [69.9, 7238.0], [70.0, 7538.0], [70.1, 7538.0], [70.2, 7538.0], [70.3, 7538.0], [70.4, 7538.0], [70.5, 7538.0], [70.6, 7538.0], [70.7, 7538.0], [70.8, 7538.0], [70.9, 7538.0], [71.0, 7544.0], [71.1, 7544.0], [71.2, 7544.0], [71.3, 7544.0], [71.4, 7544.0], [71.5, 7544.0], [71.6, 7544.0], [71.7, 7544.0], [71.8, 7544.0], [71.9, 7544.0], [72.0, 7586.0], [72.1, 7586.0], [72.2, 7586.0], [72.3, 7586.0], [72.4, 7586.0], [72.5, 7586.0], [72.6, 7586.0], [72.7, 7586.0], [72.8, 7586.0], [72.9, 7586.0], [73.0, 7635.0], [73.1, 7635.0], [73.2, 7635.0], [73.3, 7635.0], [73.4, 7635.0], [73.5, 7635.0], [73.6, 7635.0], [73.7, 7635.0], [73.8, 7635.0], [73.9, 7635.0], [74.0, 7895.0], [74.1, 7895.0], [74.2, 7895.0], [74.3, 7895.0], [74.4, 7895.0], [74.5, 7895.0], [74.6, 7895.0], [74.7, 7895.0], [74.8, 7895.0], [74.9, 7895.0], [75.0, 8026.0], [75.1, 8026.0], [75.2, 8026.0], [75.3, 8026.0], [75.4, 8026.0], [75.5, 8026.0], [75.6, 8026.0], [75.7, 8026.0], [75.8, 8026.0], [75.9, 8026.0], [76.0, 8029.0], [76.1, 8029.0], [76.2, 8029.0], [76.3, 8029.0], [76.4, 8029.0], [76.5, 8029.0], [76.6, 8029.0], [76.7, 8029.0], [76.8, 8029.0], [76.9, 8029.0], [77.0, 8076.0], [77.1, 8076.0], [77.2, 8076.0], [77.3, 8076.0], [77.4, 8076.0], [77.5, 8076.0], [77.6, 8076.0], [77.7, 8076.0], [77.8, 8076.0], [77.9, 8076.0], [78.0, 8163.0], [78.1, 8163.0], [78.2, 8163.0], [78.3, 8163.0], [78.4, 8163.0], [78.5, 8163.0], [78.6, 8163.0], [78.7, 8163.0], [78.8, 8163.0], [78.9, 8163.0], [79.0, 8193.0], [79.1, 8193.0], [79.2, 8193.0], [79.3, 8193.0], [79.4, 8193.0], [79.5, 8193.0], [79.6, 8193.0], [79.7, 8193.0], [79.8, 8193.0], [79.9, 8193.0], [80.0, 8225.0], [80.1, 8225.0], [80.2, 8225.0], [80.3, 8225.0], [80.4, 8225.0], [80.5, 8225.0], [80.6, 8225.0], [80.7, 8225.0], [80.8, 8225.0], [80.9, 8225.0], [81.0, 8248.0], [81.1, 8248.0], [81.2, 8248.0], [81.3, 8248.0], [81.4, 8248.0], [81.5, 8248.0], [81.6, 8248.0], [81.7, 8248.0], [81.8, 8248.0], [81.9, 8248.0], [82.0, 8286.0], [82.1, 8286.0], [82.2, 8286.0], [82.3, 8286.0], [82.4, 8286.0], [82.5, 8286.0], [82.6, 8286.0], [82.7, 8286.0], [82.8, 8286.0], [82.9, 8286.0], [83.0, 8424.0], [83.1, 8424.0], [83.2, 8424.0], [83.3, 8424.0], [83.4, 8424.0], [83.5, 8424.0], [83.6, 8424.0], [83.7, 8424.0], [83.8, 8424.0], [83.9, 8424.0], [84.0, 8497.0], [84.1, 8497.0], [84.2, 8497.0], [84.3, 8497.0], [84.4, 8497.0], [84.5, 8497.0], [84.6, 8497.0], [84.7, 8497.0], [84.8, 8497.0], [84.9, 8497.0], [85.0, 8622.0], [85.1, 8622.0], [85.2, 8622.0], [85.3, 8622.0], [85.4, 8622.0], [85.5, 8622.0], [85.6, 8622.0], [85.7, 8622.0], [85.8, 8622.0], [85.9, 8622.0], [86.0, 8642.0], [86.1, 8642.0], [86.2, 8642.0], [86.3, 8642.0], [86.4, 8642.0], [86.5, 8642.0], [86.6, 8642.0], [86.7, 8642.0], [86.8, 8642.0], [86.9, 8642.0], [87.0, 8664.0], [87.1, 8664.0], [87.2, 8664.0], [87.3, 8664.0], [87.4, 8664.0], [87.5, 8664.0], [87.6, 8664.0], [87.7, 8664.0], [87.8, 8664.0], [87.9, 8664.0], [88.0, 8687.0], [88.1, 8687.0], [88.2, 8687.0], [88.3, 8687.0], [88.4, 8687.0], [88.5, 8687.0], [88.6, 8687.0], [88.7, 8687.0], [88.8, 8687.0], [88.9, 8687.0], [89.0, 8716.0], [89.1, 8716.0], [89.2, 8716.0], [89.3, 8716.0], [89.4, 8716.0], [89.5, 8716.0], [89.6, 8716.0], [89.7, 8716.0], [89.8, 8716.0], [89.9, 8716.0], [90.0, 8724.0], [90.1, 8724.0], [90.2, 8724.0], [90.3, 8724.0], [90.4, 8724.0], [90.5, 8724.0], [90.6, 8724.0], [90.7, 8724.0], [90.8, 8724.0], [90.9, 8724.0], [91.0, 8749.0], [91.1, 8749.0], [91.2, 8749.0], [91.3, 8749.0], [91.4, 8749.0], [91.5, 8749.0], [91.6, 8749.0], [91.7, 8749.0], [91.8, 8749.0], [91.9, 8749.0], [92.0, 8758.0], [92.1, 8758.0], [92.2, 8758.0], [92.3, 8758.0], [92.4, 8758.0], [92.5, 8758.0], [92.6, 8758.0], [92.7, 8758.0], [92.8, 8758.0], [92.9, 8758.0], [93.0, 8855.0], [93.1, 8855.0], [93.2, 8855.0], [93.3, 8855.0], [93.4, 8855.0], [93.5, 8855.0], [93.6, 8855.0], [93.7, 8855.0], [93.8, 8855.0], [93.9, 8855.0], [94.0, 8906.0], [94.1, 8906.0], [94.2, 8906.0], [94.3, 8906.0], [94.4, 8906.0], [94.5, 8906.0], [94.6, 8906.0], [94.7, 8906.0], [94.8, 8906.0], [94.9, 8906.0], [95.0, 10001.0], [95.1, 10001.0], [95.2, 10001.0], [95.3, 10001.0], [95.4, 10001.0], [95.5, 10001.0], [95.6, 10001.0], [95.7, 10001.0], [95.8, 10001.0], [95.9, 10001.0], [96.0, 10001.0], [96.1, 10001.0], [96.2, 10001.0], [96.3, 10001.0], [96.4, 10001.0], [96.5, 10001.0], [96.6, 10001.0], [96.7, 10001.0], [96.8, 10001.0], [96.9, 10001.0], [97.0, 10002.0], [97.1, 10002.0], [97.2, 10002.0], [97.3, 10002.0], [97.4, 10002.0], [97.5, 10002.0], [97.6, 10002.0], [97.7, 10002.0], [97.8, 10002.0], [97.9, 10002.0], [98.0, 10002.0], [98.1, 10002.0], [98.2, 10002.0], [98.3, 10002.0], [98.4, 10002.0], [98.5, 10002.0], [98.6, 10002.0], [98.7, 10002.0], [98.8, 10002.0], [98.9, 10002.0], [99.0, 10002.0], [99.1, 10002.0], [99.2, 10002.0], [99.3, 10002.0], [99.4, 10002.0], [99.5, 10002.0], [99.6, 10002.0], [99.7, 10002.0], [99.8, 10002.0], [99.9, 10002.0]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 1.0, "minX": 700.0, "maxY": 6.0, "series": [{"data": [[8200.0, 3.0], [8400.0, 2.0], [8600.0, 4.0], [8700.0, 4.0], [8900.0, 1.0], [8800.0, 1.0], [10000.0, 5.0], [700.0, 1.0], [900.0, 1.0], [1000.0, 1.0], [1100.0, 2.0], [1200.0, 2.0], [1300.0, 1.0], [1400.0, 1.0], [1500.0, 1.0], [1800.0, 3.0], [1900.0, 1.0], [2000.0, 1.0], [2100.0, 3.0], [2200.0, 2.0], [2300.0, 2.0], [2400.0, 1.0], [2500.0, 1.0], [2600.0, 5.0], [2700.0, 2.0], [2800.0, 3.0], [2900.0, 3.0], [3200.0, 4.0], [3300.0, 1.0], [3400.0, 1.0], [3800.0, 2.0], [4000.0, 2.0], [4200.0, 2.0], [4400.0, 1.0], [4600.0, 1.0], [4700.0, 6.0], [4800.0, 2.0], [4900.0, 2.0], [5000.0, 3.0], [5200.0, 3.0], [5300.0, 2.0], [7200.0, 1.0], [7500.0, 3.0], [7600.0, 1.0], [7800.0, 1.0], [8000.0, 3.0], [8100.0, 2.0]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 10000.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 5.0, "minX": 1.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 86.0, "series": [{"data": [], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[1.0, 9.0]], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [[2.0, 86.0]], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [[3.0, 5.0]], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 3.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 50.34, "minX": 1.7059023E12, "maxY": 50.34, "series": [{"data": [[1.7059023E12, 50.34]], "isOverall": false, "label": "SearchUser", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.7059023E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 10800000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 943.0, "minX": 1.0, "maxY": 10002.0, "series": [{"data": [[2.0, 10001.0], [3.0, 10002.0], [4.0, 10001.0], [5.0, 10002.0], [6.0, 8716.0], [7.0, 8687.0], [8.0, 8724.0], [9.0, 8855.0], [10.0, 8642.0], [11.0, 8758.0], [12.0, 8749.0], [13.0, 8906.0], [14.0, 8664.0], [15.0, 8622.0], [16.0, 8497.0], [17.0, 8424.0], [18.0, 8286.0], [19.0, 8225.0], [20.0, 8248.0], [21.0, 8163.0], [22.0, 8193.0], [23.0, 8076.0], [24.0, 8026.0], [25.0, 8029.0], [26.0, 7895.0], [27.0, 7635.0], [28.0, 7586.0], [29.0, 7538.0], [30.0, 7544.0], [31.0, 7238.0], [33.0, 5335.0], [32.0, 5350.0], [35.0, 4907.0], [34.0, 5218.0], [37.0, 5217.0], [36.0, 5239.0], [39.0, 5055.0], [38.0, 5055.0], [41.0, 4725.0], [40.0, 5043.0], [43.0, 4969.0], [42.0, 4839.0], [45.0, 4837.0], [44.0, 4788.0], [47.0, 4734.0], [46.0, 4765.0], [49.0, 4708.0], [48.0, 4726.0], [51.0, 4624.0], [50.0, 4086.0], [53.0, 4296.0], [52.0, 4463.0], [55.0, 4209.0], [54.0, 3801.0], [57.0, 3452.0], [56.0, 4049.0], [59.0, 3243.0], [58.0, 3275.0], [61.0, 3256.0], [60.0, 3822.0], [63.0, 2994.0], [62.0, 2995.0], [67.0, 3289.0], [66.0, 2775.0], [65.0, 2943.0], [64.0, 3342.0], [71.0, 2577.0], [70.0, 2868.0], [69.0, 2841.0], [75.0, 2601.0], [74.0, 2645.0], [73.0, 2714.0], [72.0, 2669.0], [79.0, 2383.0], [78.0, 2637.0], [77.0, 2428.0], [76.0, 2605.0], [82.0, 1453.5], [83.0, 2215.0], [81.0, 2242.0], [80.0, 2381.0], [87.0, 1924.0], [86.0, 2119.0], [85.0, 2041.0], [84.0, 2150.0], [91.0, 1530.0], [90.0, 1812.0], [89.0, 1818.0], [88.0, 1846.0], [95.0, 1269.0], [94.0, 1264.0], [93.0, 1339.0], [92.0, 1445.0], [99.0, 943.0], [98.0, 1088.0], [97.0, 1184.0], [96.0, 1186.0], [1.0, 10002.0]], "isOverall": false, "label": "HTTP Request", "isController": false}, {"data": [[50.34, 4858.969999999999]], "isOverall": false, "label": "HTTP Request-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 99.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 204.25, "minX": 1.7059023E12, "maxY": 9805906.166666666, "series": [{"data": [[1.7059023E12, 9805906.166666666]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.7059023E12, 204.25]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.7059023E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 10800000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 4858.969999999999, "minX": 1.7059023E12, "maxY": 4858.969999999999, "series": [{"data": [[1.7059023E12, 4858.969999999999]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.7059023E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 10800000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 4314.179999999999, "minX": 1.7059023E12, "maxY": 4314.179999999999, "series": [{"data": [[1.7059023E12, 4314.179999999999]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.7059023E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 10800000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 3.6099999999999985, "minX": 1.7059023E12, "maxY": 3.6099999999999985, "series": [{"data": [[1.7059023E12, 3.6099999999999985]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.7059023E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 10800000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 714.0, "minX": 1.7059023E12, "maxY": 8906.0, "series": [{"data": [[1.7059023E12, 8906.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.7059023E12, 714.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.7059023E12, 8630.0]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.7059023E12, 8906.0]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.7059023E12, 4209.0]], "isOverall": false, "label": "Median", "isController": false}, {"data": [[1.7059023E12, 8729.0]], "isOverall": false, "label": "95th percentile", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.7059023E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 10800000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 828.5, "minX": 1.0, "maxY": 10002.0, "series": [{"data": [[2.0, 828.5], [1.0, 7238.0], [17.0, 2383.0], [9.0, 4086.0], [18.0, 4938.0], [11.0, 1339.0], [12.0, 6123.0], [13.0, 8029.0]], "isOverall": false, "label": "Successes", "isController": false}, {"data": [[5.0, 10002.0]], "isOverall": false, "label": "Failures", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 18.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 0.0, "minX": 1.0, "maxY": 8000.0, "series": [{"data": [[2.0, 799.0], [1.0, 7182.0], [17.0, 2353.0], [9.0, 4056.0], [18.0, 4884.0], [11.0, 1301.0], [12.0, 6098.0], [13.0, 8000.0]], "isOverall": false, "label": "Successes", "isController": false}, {"data": [[5.0, 0.0]], "isOverall": false, "label": "Failures", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 18.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 1.6666666666666667, "minX": 1.7059023E12, "maxY": 1.6666666666666667, "series": [{"data": [[1.7059023E12, 1.6666666666666667]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.7059023E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 10800000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 0.08333333333333333, "minX": 1.7059023E12, "maxY": 1.5833333333333333, "series": [{"data": [[1.7059023E12, 1.5833333333333333]], "isOverall": false, "label": "200", "isController": false}, {"data": [[1.7059023E12, 0.08333333333333333]], "isOverall": false, "label": "Non HTTP response code: java.net.SocketException", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.7059023E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 10800000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 0.08333333333333333, "minX": 1.7059023E12, "maxY": 1.5833333333333333, "series": [{"data": [[1.7059023E12, 1.5833333333333333]], "isOverall": false, "label": "HTTP Request-success", "isController": false}, {"data": [[1.7059023E12, 0.08333333333333333]], "isOverall": false, "label": "HTTP Request-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.7059023E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 10800000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 0.08333333333333333, "minX": 1.7059023E12, "maxY": 1.5833333333333333, "series": [{"data": [[1.7059023E12, 1.5833333333333333]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [[1.7059023E12, 0.08333333333333333]], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.7059023E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 10800000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

